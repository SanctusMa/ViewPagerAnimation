# ViewPagerAnimation
ViewPagerAnimation


16个效果名：

0.左右黏合滑动
1.快速消失切入
2.3D向前飞出屏幕
3.3D箱子旋转
4.平移
5.卡片左右翻页
6.卡片上下翻页
7.等比放大缩小
8左右带角度平移1
9左右带角度平移2
10.好像没有写case10.
11.遮盖翻页
12.内旋3D翻页
13.不翻页中心缩小
14.左右半透明平移
15.改变透明度变换
16.左右黏贴平移



```
viewPager.setPageTransformer(true,
								new DepthPageTransformer());
```


```
 compile files('libs/androidannotations-api-3.2.jar')
```


![image](http://img.blog.csdn.net/20151210134957919)



![image](http://img.blog.csdn.net/20151210135024373)



![image](http://img.blog.csdn.net/20151210135042382)
